using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class GameManager : MonoBehaviour
{
	public static void SpawnLittleObjects(int count, GameObject obj, float g, Vector3 pos, Vector2 forceDir = Vector2.zero, float force = 2f){
		for(int i = 0; i < count; i++){
			var inst = Instantiate(obj, pos, obj.rotation);
			if(inst.GetComponent<Rigidbody2D>() == null)
				var rb = inst.AddComponent<Rigidbody2D>();
			rb.gravityScale = g;
			var rb = inst.GetComponent<Rigidbody2D>();
			rb.AddForce(forceDir * force, ForceMode2D.Impulse);
		}
	}
}
