using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class enemyDeath : MonoBehaviour
{
    [SerializeField] trident t;
	
	[SerializeField] GameObject boneObj;
	
	private float health;
	public List<float> healthForType = {
		1f, 4f, 6f
	};
	public float tridentMeleeDamage = 1f;
	public float throwDamageDivider = 10f;
	
	void Start()
	{
		if(GetComponent<Fish>() != null) health = healthForType[0];
		else if(GetComponent<Pirate>() != null) health = healthForType[1];
		else health = healthForType[2];
	}
	
    void OnTriggerEnter2D(Collider2D other)
    {
        if(other.tag == "tridentTip"){
            if(t.hasEnoughVel || t.playerAttacking){
                if(t.thrown)
					health -= t.throwForce / throwDamageDivider;
				else
					health -= tridentMeleeDamage;
            }
        }
    }
	
    void OnTriggerStay2D(Collider2D other)
    {
        if(other.tag == "tridentTip"){
            if(t.thrown)
				health -= t.throwForce / throwDamageDivider;
			else
				health -= tridentMeleeDamage;
        }
    }
	
    void Update()
    {
		if(health <= 0f) Die();
        Debug.Log(t.hasEnoughVel);
    }
	
	public void Die(){
		int count = Random.Range(4, 8);
		float g = 0f;
		Vector3 pos = transform.position;
		Vector2 forceDir = Random.insideUnitCircle;
		GameManager.SpawnLittleObjects(count, boneObj, g, pos, forceDir);
		Destroy(gameObject);
	}
}
